---
name: Clinical Academic Precision
colors:
  surface: '#f9f9ff'
  surface-dim: '#cbdbf8'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff3ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dde9ff'
  surface-container-highest: '#d4e3ff'
  on-surface: '#0b1c31'
  on-surface-variant: '#434752'
  inverse-surface: '#213147'
  inverse-on-surface: '#ebf1ff'
  outline: '#737783'
  outline-variant: '#c3c6d3'
  surface-tint: '#2a5caf'
  primary: '#002f6c'
  on-primary: '#ffffff'
  primary-container: '#004497'
  on-primary-container: '#94b6ff'
  inverse-primary: '#aec6ff'
  secondary: '#405aaa'
  on-secondary: '#ffffff'
  secondary-container: '#8ea8fd'
  on-secondary-container: '#1c3a88'
  tertiary: '#002e6e'
  on-tertiary: '#ffffff'
  tertiary-container: '#00439b'
  on-tertiary-container: '#96b5ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#aec6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004396'
  secondary-fixed: '#dce1ff'
  secondary-fixed-dim: '#b5c4ff'
  on-secondary-fixed: '#00164d'
  on-secondary-fixed-variant: '#254190'
  tertiary-fixed: '#d9e2ff'
  tertiary-fixed-dim: '#afc6ff'
  on-tertiary-fixed: '#001944'
  on-tertiary-fixed-variant: '#004299'
  background: '#f9f9ff'
  on-background: '#0b1c31'
  surface-variant: '#d4e3ff'
typography:
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-sm: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system delivers a serene, rigorous, and trustworthy digital environment tailored for university hospital healthcare scheduling and clinical-academic operations. The visual language balances clinical precision with academic dignity, projecting utmost competence, empathy, and institutional prestige.

The style is defined as **Corporate & Academic Minimalism**:
- **Canvas Character:** Predominantly pure white `#FFFFFF` workspaces structured atop soft structural neutral canvases (`#F6F8FC`).
- **Visual Weight:** Restrained and calm. Visual hierarchy is established through structural typography and delicate, low-contrast borders rather than dense fills or heavy shadows.
- **Academic Signifiers:** A persistent yet non-intrusive status pill badge ("Prototipo académico · Datos ficticios") anchors the interface context at all times, styled in subdued slate tones to provide clarity without impeding clinical workflows.
- **Emotional Response:** Inspires reassurance, focus, and frictionless scheduling for medical faculty, resident doctors, administrative staff, and patients alike.

## Colors

The palette establishes an authoritative, accessible, and hygienic tone with high legibility across clinical monitors and mobile devices.

### Functional Palette Mapping
- **Primary Blue (`#004497`):** Direct action items, primary button fills, active navigation states, key step indicators.
- **Deep Blue (`#002777`):** Editorial headings, primary table titles, institutional markers, and high-emphasis labels.
- **Accent Blue (`#0370F8`):** Focus rings, interactive highlights, text-based action links, and progress counters.
- **Pale Blue (`#E4F4FB`):** Subtle informational callout surfaces, banner backgrounds, and selected table row tints.
- **Dark Neutral (`#1B2B41`):** Primary body text, table row contents, input values, and dense clinical data points.
- **Muted Neutral (`#59687C`):** Form helper labels, secondary captions, inactive pagination elements, and metadata timestamps.
- **Border Neutral (`#E5EAF1`):** Structural borders for cards, inputs, calendar day grids, and horizontal dividers.
- **Soft Neutral Canvas (`#F6F8FC`):** Application base canvas underlying primary workspace surfaces.

### Semantic Tiers
Always pair semantic fills with their calibrated high-contrast text tones:
- **Success:** `#107C41` text on `#E6F4EA` surface (confirmed appointments, completed checklists).
- **Pending / Warning:** `#D97706` text on `#FEF3C7` surface (unconfirmed slots, pending residency approvals).
- **Destructive / Alert:** `#DC2626` text on `#FEE2E2` surface (cancellations, slot conflicts, system alerts).

## Typography

The type system is engineered around **Plus Jakarta Sans**, offering a clean geometric sans-serif aesthetic with balanced letterforms, clear numerals for clinical schedules, and open apertures for high legibility under varying lighting conditions.

### Rules & Hierarchy
- **Headings (`headline-lg`, `headline-md`, `headline-sm`):** Rendered in Semibold (`600`) with Deep Blue (`#002777`) to deliver structural cadence across dashboards, calendar navigation headers, and modal titles.
- **Controls & Buttons (`title-md`, `label-lg`, `label-md`):** Rendered in Medium (`500`) to guarantee distinct interactive touchpoint affordance without visual noise.
- **Body & Clinical Descriptions (`body-lg`, `body-md`):** Rendered in Regular (`400`) using Dark Neutral (`#1B2B41`) at 16px baseline for fatigue-free reading across extended clinical sessions.
- **Metadata & Subtitles:** Set in Muted Neutral (`#59687C`) using `label-md` or `label-sm`.

## Layout & Spacing

The layout is constructed on an immutable **8px spatial grid** with clear baseline alignment across all cards, form groups, and calendar slots.

### Layout Model
- **Grid Structure:** 12-column responsive fluid grid on desktop (`1200px+`) with `24px` (`1.5rem`) gutters and `32px` (`2rem`) margins. Max container constraint of `1440px`.
- **Tablet (`768px – 1199px`):** 8-column layout with `16px` (`1rem`) gutters and `24px` margins. Side navigation collapses into an accessible slide-over rail.
- **Mobile (`< 768px`):** 4-column single-stack flow with `16px` outer margins. Interactive touchpoints remain strictly within thumb zones with a minimum 44px vertical target.

### Structural Rhythm
- Form field stacks and input groups strictly employ `space-md` (16px) separation.
- Component-level internal padding utilizes `space-lg` (24px) for card containers and `space-sm` / `space-md` for control elements.

## Elevation & Depth

Visual depth follows a restrained, clinical-layering philosophy prioritizing crisp outlines over dramatic shadows. Ambient light is simulated through faint blue-gray tinting rather than standard black drops.

- **Layer 0 (Base Canvas):** `#F6F8FC`. Provides contrast for elevated functional white planes.
- **Layer 1 (Cards, Tables, Panels):** Pure `#FFFFFF` resting with a 1px border of `#E5EAF1` and an ambient shadow: `0 1px 3px 0 rgba(27, 43, 65, 0.04), 0 1px 2px -1px rgba(27, 43, 65, 0.02)`.
- **Layer 2 (Floating Pickers, Popovers, Dropdowns):** `#FFFFFF` with a 1px `#E5EAF1` border and structured drop: `0 8px 16px -4px rgba(27, 43, 65, 0.08), 0 2px 4px -2px rgba(27, 43, 65, 0.04)`.
- **Layer 3 (Modal Dialogs & Drawers):** `#FFFFFF` overlay supported by a backdrop filter: `rgba(27, 43, 65, 0.35)` with `backdrop-blur(2px)` and shadow `0 20px 24px -4px rgba(27, 43, 65, 0.12)`.

## Shapes

The shape system adopts a hybrid approach: purposeful softenings that project modern, approachable warmth while maintaining institutional stability.

- **Workspace Cards & Modules:** `16px` border-radius (`1rem`). Large enough to define clean separation between appointment clusters, but structured enough to align crisply in multi-column dashboards.
- **Controls, Buttons & Input Fields:** `10px` border-radius (`0.625rem`), balancing precision with tactile comfort.
- **Badges, Status Chips, & Academic Indicator:** Fully rounded pill-shape (`9999px`) for quick visual scanning.

## Components

### Academic Prototype Notice
- **Specs:** Positioned in the global application header or fixed footer banner. Border: 1px solid `#E5EAF1`; Background: `#F6F8FC`; Typography: `label-sm` in `#59687C`. Contains a small leading dot indicator (`#D97706`) and the text: `Prototipo académico · Datos ficticios`.

### Buttons
- **Touch Target:** Minimum height `44px`, horizontal padding `20px` (`space-md` + `space-xs`), corner radius `10px`.
- **Primary:** Background `#004497`, text `#FFFFFF`, font-weight `500`. Hover: `#002777`. Active: transform scale `0.98`. Focus-visible: outline `2px solid #0370F8` with `2px` offset.
- **Secondary / Outline:** Background `#FFFFFF`, border `1px solid #E5EAF1`, text `#004497`. Hover: `#F6F8FC`, border `#004497`.
- **Ghost:** Text `#004497`, background `transparent`. Hover: `#E4F4FB`.

### Form Fields & Inputs
- **Touch Target:** Height `44px`, corner radius `10px`, background `#FFFFFF`, border `1px solid #E5EAF1`.
- **Padding:** `0 14px`.
- **States:** Active/Focus displays border `1.5px solid #0370F8` with an outer ring `3px rgba(3, 112, 248, 0.15)`. Error states apply border `1px solid #DC2626` with hint text in `#DC2626`.

### Cards & Appointment Modules
- **Container:** Pure `#FFFFFF` surface, corner radius `16px`, 1px border `#E5EAF1`, minimal elevation Layer 1. Internal padding `24px` (`space-lg`).
- **Header:** Title in `#002777` (`headline-sm` or `title-lg`) paired with right-aligned status chip.

### Status Chips
- **Container:** Height `26px`, corner radius `9999px`, horizontal padding `10px`, font size `12px` (`label-md`).
- **Confirmed:** Background `#E6F4EA`, text `#107C41`.
- **Pending:** Background `#FEF3C7`, text `#D97706`.
- **Cancelled / Critical:** Background `#FEE2E2`, text `#DC2626`.
- **Informational / General:** Background `#E4F4FB`, text `#004497`.

### Lists & Timetable Slots
- **Slot Rows:** 1px border bottom `#E5EAF1`. Row hover introduces `#F6F8FC` background transition. Selected appointment slot transitions to `#E4F4FB` with a `3px` left border in `#004497`.
- **Typography:** Time slot figures in `title-md` `#002777`; patient & specialty descriptions in `body-md` `#1B2B41`.

### Checkboxes & Radio Controls
- **Size:** `20px × 20px`, 6px corner radius for checkboxes, circle for radio buttons.
- **Border:** `1.5px solid #E5EAF1`.
- **Checked:** Background `#004497`, border `#004497` with white checkmark/bullet.